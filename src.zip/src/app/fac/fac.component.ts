import { Component } from '@angular/core';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-fac',
  templateUrl: './fac.component.html',
  styleUrl: './fac.component.css'
})
export class FacComponent {

stulist:any[]=[];
constructor(private studentsService:ServicesService)
{

}
getDetails(){
  this.stulist=this.studentsService.getDetails();
}
}
