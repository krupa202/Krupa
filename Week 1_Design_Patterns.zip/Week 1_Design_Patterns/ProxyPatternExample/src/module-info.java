/**
 * 
 */
/**
 * 
 */
module ProxyPatternExample {
}