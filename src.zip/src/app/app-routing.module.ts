import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StuComponent } from './stu/stu.component';
import { FacComponent } from './fac/fac.component';

const routes: Routes = [
  {path:'stu' ,component:StuComponent},
  {path:'fac', component:FacComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
