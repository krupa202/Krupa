import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {
  stulist:any[]=[];
  addStudent(name:string,act:string)
  {
    this.stulist.push({name:name,acti:act});
  }
  getDetails()
  {
    return this.stulist;
  }
  constructor() { }
}
