package decoratorPatternExample;

public interface Notifier {
	 void send(String message);
}
