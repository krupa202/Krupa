import { Component } from '@angular/core';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-stu',
  templateUrl: './stu.component.html',
  styleUrl: './stu.component.css'
})
export class StuComponent {
  stulist:any[]=[];
  constructor(private stu : ServicesService){}
  addStudent(name:string,act:string)
  {
    this.stu.addStudent(name,act);
    alert("Student details entered successfully");
  }
}
