package commandPatternExample;

public interface Command {
	void execute();
}
